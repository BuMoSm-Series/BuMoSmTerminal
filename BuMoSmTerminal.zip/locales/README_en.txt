================================================================
BuMoSm Terminal — About Theme Files
================================================================

Any .json file placed in this folder is loaded as a theme when
the application starts.
Files are reloaded automatically when changed, so you can edit
a theme and see the result without restarting.


----------------------------------------------------------------
The two "name" keys (read this first)
----------------------------------------------------------------

A theme file contains a key called "name" in two places.
They serve completely different purposes, so be careful not to
confuse them.

  {
    "name": "BuMoSm Terminal Theme",   <- [1] near line 2
    "themes": [
      {
        "name": "BuMoSm Light",        <- [2] this is what the
        ...                                  settings screen shows
      }
    ]
  }

[1] The top-level "name"

  Meaning : The name of the theme file as a whole.
  Shown   : Never shown on the settings screen.
  Editing : You do not need to edit it.
            All theme files for this application use
            "BuMoSm Terminal Theme".
            Keep this value as it is when you create a new file.
  Note    : The value is discarded after loading, so it is fine
            for several files to share the same value.
            Changing it has no visible effect.

[2] The "name" inside "themes"

  Meaning : The name of an individual theme.
  Shown   : Listed under "Theme" on the settings screen.
  Editing : Edit this if you want to change the displayed name.
  Note    : Names must be unique across all theme files.
            If two themes share a name, the one loaded later
            replaces the earlier one and disappears from the
            settings screen.
            File load order is not defined, so which one
            survives is not predictable either.


----------------------------------------------------------------
File structure
----------------------------------------------------------------

The top level of a theme file requires two keys.

  "name"    — The name of the theme file as a whole.
               Keep it as "BuMoSm Terminal Theme".

  "themes"  — An array of theme objects.
               Each object becomes one entry in the settings
               screen list.

Keys of each theme object:

  "name"       — Name shown on the settings screen. (required)
                 Must be unique across all theme files.

  "mode"       — Either "light" or "dark". (required)
                 Decides which side this theme applies to when
                 "Follow OS" is selected.

  "colors"     — An object of color assignments. (required)
                 See the list below for available keys.

  "is_default" — Optional.
                 Places the theme earlier in the settings list.


----------------------------------------------------------------
Writing colors
----------------------------------------------------------------

Values in "colors" accept the following formats.

  Hex color     — "#rrggbb" or "#rrggbbaa"
                  e.g. "#ffffff", "#1a1a1aff"

  Tailwind name — A Tailwind CSS color name and shade number.
                  e.g. "neutral-950", "blue-400", "white", "black"
                  Shades are 50, 100-900 (in steps of 100), 950.

  Transparent   — "#00000000" (useful for things such as the
                  scrollbar track)

The last two digits set the alpha channel.
When omitted, the color is treated as fully opaque.

Keys you leave out fall back to the built-in default for that
mode (light/dark). You do not need to specify every key.

Misspelled keys are silently ignored rather than reported as an
error. If a color change has no effect, compare the key name
against the list below.


================================================================
Colors used directly by this application (17 keys)
================================================================

The main window (toolbar, log area, status bar, connect toggle,
display-mode toggle) is built from the keys below.
Changing these will visibly change the application.


----------------------------------------------------------------
* Overall (4 keys)
----------------------------------------------------------------

  background
    Base color of the window.
    Also used as the background of the log area.
    This is the key with the widest visual impact.

  foreground
    Base text color.
    Also used for the text in the OS-drawn title bar.

  border
    Color of dividing lines.
    Used for the line under the toolbar, above the send field,
    above the status bar, around toggles, and the window frame.

  selection.background
    Highlight color when selecting text in the log area.
    Transparency is decided by the application, so specify an
    opaque color here.


----------------------------------------------------------------
* Title bar and status bar (2 keys)
----------------------------------------------------------------

  title_bar.background
    Base color of the OS-drawn title bar.
    Applies on Windows 11 only.

  status_bar.background
    Base color of the status bar at the bottom of the window.


----------------------------------------------------------------
* Subdued colors (2 keys)
----------------------------------------------------------------

  muted.foreground
    Subdued text color.
    Used for the status bar text (connection state and the
    communication settings shown there).

  muted.background
    Base color of a toggle that cannot be pressed.
    Used for the Connect toggle when the required settings are
    not filled in.


----------------------------------------------------------------
* Accent (2 keys)
----------------------------------------------------------------

  primary.background
    Base color of the selected toggle.
    Used for whichever side is active in the Text / Hex display
    switch. This is the most eye-catching color on screen.

  primary.foreground
    Text color of the selected toggle.
    Choose something readable on top of primary.background.


----------------------------------------------------------------
* Scrollbar (3 keys)
----------------------------------------------------------------

Used by the scrollbar of the log area.
Transparency is decided by the application, so specify opaque
colors here.

  scrollbar.background
    Color of the scrollbar track.
    Rendered very faintly, so it is barely visible in practice.

  scrollbar.thumb.background
    Color of the thumb.

  scrollbar.thumb.hover.background
    Color of the thumb while the mouse is over it.
    Rendered darker than normal to show it can be grabbed.


----------------------------------------------------------------
* Settings screen (4 keys)
----------------------------------------------------------------

The settings screen is drawn by the component library.
These keys stand out the most there.

  input.border
    Border around text fields and select boxes.

  popover.background
    Background of the list shown when a select box is opened.

  popover.foreground
    Its text color.

  accent.background
    Background of the currently selected entry in that list.


================================================================
Other settings-screen colors
================================================================

Beyond the above, the settings-screen components (buttons,
switches, lists) read the following keys. The defaults are fine,
but you can set them for a closer match.

  ring                              Focus ring
  caret                             Text field caret
  title_bar.border                  Line under the title bar
  status_bar.border                 Line above the status bar
  accent.foreground                 Text of the selected entry
  primary.hover.background          Accent button, hovered
  primary.active.background         Accent button, pressed
  secondary.background              Subdued button base
  secondary.foreground              Its text color
  secondary.hover.background        Hovered
  secondary.active.background       Pressed
  button.background                 Normal button base
  button.foreground                 Its text color
  button.hover.background           Hovered
  button.active.background          Pressed
  danger.background                 Error color
  danger.foreground                 Text on the error color
  list.hover.background             List row, hovered
  list.active.background            Selected list row
  switch.background                 Switch track
  switch.thumb.background           Switch thumb
  drag.border                       Frame shown while dragging


================================================================
Colors themes cannot change
================================================================

The text colors for sent and received data are not part of the
theme. They are set individually under "Send Color" and
"Recv Color" on the settings screen.

Those colors exist to tell the direction of the data apart, so
they follow your preference rather than the surrounding
brightness. Switching themes does not change them.

After switching to a dark theme, check that the send and receive
colors are still readable against the background. You can change
them to brighter colors on the settings screen if needed.


================================================================
Minimal example
================================================================

{
  "name": "BuMoSm Terminal Theme",
  "themes": [
    {
      "name": "My Dark",
      "mode": "dark",
      "colors": {
        "background": "#1e1e1e",
        "foreground": "#d4d4d4",
        "border": "#3e3e3e",
        "selection.background": "#4a9eff",
        "title_bar.background": "#2d2d2d",
        "status_bar.background": "#2d2d2d",
        "muted.background": "#2a2a2a",
        "muted.foreground": "#9a9a9a",
        "primary.background": "#0e639c",
        "primary.foreground": "#ffffff",
        "scrollbar.background": "#1e1e1e00",
        "scrollbar.thumb.background": "#5a5a5a",
        "scrollbar.thumb.hover.background": "#7a7a7a",
        "input.border": "#3e3e3e",
        "popover.background": "#252526",
        "popover.foreground": "#d4d4d4",
        "accent.background": "#264f78"
      }
    }
  ]
}

The settings screen shows "My Dark".
"BuMoSm Terminal Theme" is shown nowhere.


================================================================
Several themes in one file
================================================================

You can place multiple objects in the "themes" array, for
example to keep a matching light and dark pair together.

{
  "name": "BuMoSm Terminal Theme",
  "themes": [
    { "name": "Solarized Light", "mode": "light", "colors": { ... } },
    { "name": "Solarized Dark",  "mode": "dark",  "colors": { ... } }
  ]
}

The settings screen then lists "Solarized Light" and
"Solarized Dark" as two separate entries.


================================================================
Notes
================================================================

- A file containing a JSON syntax error is ignored on load.
  It does not appear in the settings list either.

- Misspelled keys are silently ignored rather than reported as
  an error. If a color change has no effect, compare the key
  name against the list above.

- The "Theme" list on the settings screen is split into
  "Standard" and "Theme Files". Themes placed in this folder
  appear under "Theme Files".

- Giving a theme the same "name" as a built-in theme replaces
  that built-in theme. Use a different name if you want to add
  it as a separate entry.

- If you delete the file of the theme you had selected, the
  application falls back to "Follow OS" on the next start.

================================================================
